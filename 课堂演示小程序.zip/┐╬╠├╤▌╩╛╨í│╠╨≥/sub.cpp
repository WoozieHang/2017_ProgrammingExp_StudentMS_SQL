#include<iostream>
using namespace std;
void SUB(int x , int y){
    int sum=0;
    sum = x - y;
    cout<<x<<" - "<<y<<" = "<<sum<<endl;
}