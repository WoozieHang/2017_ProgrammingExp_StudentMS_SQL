#include<iostream>
using namespace std;
void ADD(int x , int y){
    int sum=0;
    sum = x + y;
    cout<<x<<" + "<<y<<" = "<<sum<<endl;
}