#include<iostream>
using namespace std;
void PrintHello(){
    cout<<"Hello NJU"<<endl;
}

